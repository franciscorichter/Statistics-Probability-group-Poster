# Statistics-Probability-group-Poster
This is the repository to build the group poster in collaboration. 
